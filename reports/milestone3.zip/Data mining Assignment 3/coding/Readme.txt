Two SAX PAA Files Inside

SAX and PAA Choy - Full spectrum of KLSE stocks - Take long time to run
SAX and PAA Choy - Partial - First 11 stocks of KLSE stocks - take less than 5 seconds to run.